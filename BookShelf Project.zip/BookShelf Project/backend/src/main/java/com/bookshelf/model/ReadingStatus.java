package com.bookshelf.model;

public enum ReadingStatus {
    UNREAD,
    IN_PROGRESS,
    READ
} 