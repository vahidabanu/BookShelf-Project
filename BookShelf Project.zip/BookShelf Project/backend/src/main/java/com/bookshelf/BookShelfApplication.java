package com.bookshelf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookShelfApplication {
    public static void main(String[] args) {
        SpringApplication.run(BookShelfApplication.class, args);
    }
} 