import React from 'react';
import { Link as RouterLink } from 'react-router-dom';
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  Box,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';

function Navbar() {
  return (
    <AppBar position="static">
      <Toolbar>
        <Typography
          variant="h6"
          component={RouterLink}
          to="/"
          sx={{
            flexGrow: 1,
            textDecoration: 'none',
            color: 'inherit',
          }}
        >
          BookShelf
        </Typography>
        <Box>
          <Button
            component={RouterLink}
            to="/add"
            color="inherit"
            startIcon={<AddIcon />}
          >
            Add Book
          </Button>
        </Box>
      </Toolbar>
    </AppBar>
  );
}

export default Navbar; 