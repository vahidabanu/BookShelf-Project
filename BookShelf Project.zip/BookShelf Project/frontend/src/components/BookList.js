import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Grid,
  Card,
  CardContent,
  CardActions,
  Typography,
  Button,
  TextField,
  MenuItem,
  Box,
  IconButton,
} from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import axios from 'axios';

const API_URL = 'http://localhost:8080/api/v1/books';

function BookList() {
  const [books, setBooks] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const navigate = useNavigate();

  useEffect(() => {
    fetchBooks();
  }, []);

  const fetchBooks = async () => {
    try {
      const response = await axios.get(API_URL);
      setBooks(response.data);
    } catch (error) {
      console.error('Error fetching books:', error);
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this book?')) {
      try {
        await axios.delete(`${API_URL}/${id}`);
        fetchBooks();
      } catch (error) {
        console.error('Error deleting book:', error);
      }
    }
  };

  const handleSearch = async (e) => {
    const query = e.target.value;
    setSearchQuery(query);
    if (query) {
      try {
        const response = await axios.get(`${API_URL}/search?query=${query}`);
        setBooks(response.data);
      } catch (error) {
        console.error('Error searching books:', error);
      }
    } else {
      fetchBooks();
    }
  };

  const handleStatusFilter = async (e) => {
    const status = e.target.value;
    setStatusFilter(status);
    if (status === 'ALL') {
      fetchBooks();
    } else {
      try {
        const response = await axios.get(`${API_URL}/status/${status}`);
        setBooks(response.data);
      } catch (error) {
        console.error('Error filtering books:', error);
      }
    }
  };

  const filteredBooks = books.filter(book => {
    if (statusFilter === 'ALL') return true;
    return book.status === statusFilter;
  });

  return (
    <Box>
      <Box sx={{ mb: 3, display: 'flex', gap: 2 }}>
        <TextField
          label="Search Books"
          variant="outlined"
          value={searchQuery}
          onChange={handleSearch}
          sx={{ flexGrow: 1 }}
        />
        <TextField
          select
          label="Status"
          value={statusFilter}
          onChange={handleStatusFilter}
          sx={{ minWidth: 200 }}
        >
          <MenuItem value="ALL">All Books</MenuItem>
          <MenuItem value="UNREAD">Unread</MenuItem>
          <MenuItem value="IN_PROGRESS">In Progress</MenuItem>
          <MenuItem value="READ">Read</MenuItem>
        </TextField>
      </Box>

      <Grid container spacing={3}>
        {filteredBooks.map((book) => (
          <Grid item xs={12} sm={6} md={4} key={book.id}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  {book.title}
                </Typography>
                <Typography color="textSecondary" gutterBottom>
                  By {book.author}
                </Typography>
                <Typography variant="body2" color="textSecondary">
                  {book.description}
                </Typography>
                <Typography
                  variant="body2"
                  color="primary"
                  sx={{ mt: 1 }}
                >
                  Status: {book.status}
                </Typography>
              </CardContent>
              <CardActions>
                <IconButton
                  onClick={() => navigate(`/edit/${book.id}`)}
                  color="primary"
                >
                  <EditIcon />
                </IconButton>
                <IconButton
                  onClick={() => handleDelete(book.id)}
                  color="error"
                >
                  <DeleteIcon />
                </IconButton>
              </CardActions>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
}

export default BookList; 